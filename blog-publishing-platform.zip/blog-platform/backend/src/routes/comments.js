const router=require('express').Router(); const Comment=require('../models/Comment'); const Post=require('../models/Post'); const auth=require('../middleware/auth');
router.post('/:postId',auth,async(req,res)=>{try{if(!await Post.findById(req.params.postId))return res.status(404).json({message:'Post not found'});const comment=await Comment.create({text:req.body.text,post:req.params.postId,author:req.user._id});res.status(201).json(await comment.populate('author','name'))}catch(e){res.status(400).json({message:e.message})}});
router.delete('/:id',auth,async(req,res)=>{const c=await Comment.findOneAndDelete({_id:req.params.id,author:req.user._id});if(!c)return res.status(404).json({message:'Comment not found or not yours'});res.json({message:'Deleted'})});
module.exports=router;
