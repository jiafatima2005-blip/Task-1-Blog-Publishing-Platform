require('dotenv').config();
const express=require('express'); const mongoose=require('mongoose'); const cors=require('cors');
const authRoutes=require('./routes/auth'); const postRoutes=require('./routes/posts'); const commentRoutes=require('./routes/comments');
const app=express();
app.use(cors({origin:process.env.CLIENT_URL||'*'})); app.use(express.json());
app.get('/api/health',(req,res)=>res.json({ok:true}));
app.use('/api/auth',authRoutes); app.use('/api/posts',postRoutes); app.use('/api/comments',commentRoutes);
const port=process.env.PORT||5000;
mongoose.connect(process.env.MONGO_URI).then(()=>app.listen(port,()=>console.log(`API running on ${port}`))).catch(err=>{console.error(err);process.exit(1)});
